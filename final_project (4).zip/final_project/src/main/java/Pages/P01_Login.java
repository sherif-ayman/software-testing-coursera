package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class P01_Login {
    ChromeDriver driver;

    public P01_Login(ChromeDriver driver) {
        this.driver = driver;
    }

    private By signInloc = By.linkText("Sign In");
    private By emailloc = By.name("login[username]");
    private By passwordloc = By.name("login[password]");
    private By signInbtnloc = By.cssSelector("button[name='send']");

    public void clickSignIn() {
        driver.findElement(signInloc).click();
    }

    public void enterEmail(String email) {
        driver.findElement(emailloc).sendKeys(email);
    }

    public void enterPassword(String password) {
        driver.findElement(passwordloc).sendKeys(password);
    }

    public void clickLogin() {
        driver.findElement(signInbtnloc).click();
    }
}
