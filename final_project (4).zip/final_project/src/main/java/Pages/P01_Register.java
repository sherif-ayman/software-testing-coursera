package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class P01_Register {
    WebDriver driver;

    public P01_Register(WebDriver driver) {
        this.driver = driver;
    }

    // Locators for registration
    private By createAccountBtn = By.linkText("Create an Account");
    private By firstNameField = By.id("firstname");
    private By lastNameField = By.id("lastname");
    private By emailField = By.id("email_address");
    private By passwordField = By.id("password");
    private By confirmPasswordField = By.id("password-confirmation");
    private By registerButton = By.cssSelector("button.action.submit.primary");

    // Error messages
    private By confirmPasswordError = By.id("password-confirmation-error");
    private By passwordMismatchError = By.id("password-error");

    // Success message locator
    private By successMessage = By.cssSelector(".message-success.success.message");

    // Actions for registration
    public void clickCreateAccount() {
        driver.findElement(createAccountBtn).click();
    }

    public void enterFirstName(String firstName) {
        driver.findElement(firstNameField).sendKeys(firstName);
    }

    public void enterLastName(String lastName) {
        driver.findElement(lastNameField).sendKeys(lastName);
    }

    public void enterEmail(String email) {
        driver.findElement(emailField).sendKeys(email);
    }

    public void enterPassword(String password) {
        driver.findElement(passwordField).sendKeys(password);
    }

    public void enterConfirmPassword(String confirmPassword) {
        driver.findElement(confirmPasswordField).sendKeys(confirmPassword);
    }

    public void clickRegister() {
        driver.findElement(registerButton).click();
    }

    // Error validation for empty Confirm Password
    public boolean isConfirmPasswordErrorDisplayed() {
        return driver.findElement(confirmPasswordError).isDisplayed();
    }

    // Error validation for password mismatch
    public boolean isPasswordMismatchErrorDisplayed() {
        return driver.findElement(passwordMismatchError).isDisplayed();
    }

    // Success message validation
    public boolean isSuccessMessageDisplayed() {
        return driver.findElement(successMessage).isDisplayed();
    }

    public String getSuccessMessageText() {
        return driver.findElement(successMessage).getText();
    }
}
