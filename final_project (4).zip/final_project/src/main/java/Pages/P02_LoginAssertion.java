package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class P02_LoginAssertion {
    ChromeDriver driver;

    public P02_LoginAssertion(ChromeDriver driver) {
        this.driver = driver;
    }

    private By welcomeMessage = By.cssSelector("span[class='base']");
    private By loggedInStatus = By.className("logged-in");

    public boolean isWelcomeDisplayed() {
        return driver.findElement(welcomeMessage).isDisplayed();
    }

    public boolean ishomepagedisplayed() {
        return driver.findElement(loggedInStatus).isDisplayed();
    }
}
