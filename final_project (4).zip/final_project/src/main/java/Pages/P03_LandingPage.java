package Pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class P03_LandingPage {
    WebDriver driver;
    WebDriverWait wait;

    public P03_LandingPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        PageFactory.initElements(driver, this);
    }

    // Hot Sellers Title
    @FindBy(xpath = "//span[text()='Hot Sellers']")
    public WebElement hotSellersTitle;

    // All Product Cards Under Hot Sellers Section
    @FindBy(css = ".block.widget.block-products-list.grid .product-item")
    public List<WebElement> hotSellerCards;

    // Check if Hot Sellers Section is Visible
    public boolean isHotSellersSectionVisible() {
        try {
            return hotSellersTitle.isDisplayed();
        } catch (NoSuchElementException e) {
            return false;
        }
    }

    // Get Product Card by Product Name
    public WebElement getCardByName(String name) {
        By locator = By.xpath("//a[contains(text(),'" + name + "')]/ancestor::li");
        return wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
    }

    // Get Price Element inside the Card
    public WebElement getPriceElement(WebElement card) {
        return card.findElement(By.cssSelector(".price"));
    }

    // Get "Add to Cart" Button inside the Card
    public WebElement getAddToCartButton(WebElement card) {
        return card.findElement(By.cssSelector(".actions-primary .tocart"));
    }

    // Select Size Option (e.g., S, M, L)
    public WebElement getSizeOption(WebElement card, String size) {
        return card.findElement(By.xpath(".//div[@option-label='" + size + "']"));
    }

    // Select First Available Color Option
    public WebElement getColorOption(WebElement card) {
        return card.findElement(By.xpath(".//div[contains(@class,'color')][1]"));
    }

    // Get Cart Badge Showing Number of Items
    public WebElement getCartBadge() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".counter-number")));
    }

    // Perform Add to Cart Action for a Product
    public void addItemToCart(String productName, String size) {
        WebElement card = getCardByName(productName);
        try {
            WebElement sizeOpt = getSizeOption(card, size);
            wait.until(ExpectedConditions.elementToBeClickable(sizeOpt)).click();
        } catch (NoSuchElementException ignored) {}

        try {
            WebElement colorOpt = getColorOption(card);
            wait.until(ExpectedConditions.elementToBeClickable(colorOpt)).click();
        } catch (NoSuchElementException ignored) {}

        WebElement addToCartBtn = getAddToCartButton(card);
        wait.until(ExpectedConditions.elementToBeClickable(addToCartBtn)).click();
    }
}
