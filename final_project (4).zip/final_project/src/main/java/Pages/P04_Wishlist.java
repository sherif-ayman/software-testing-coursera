package Pages;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;

public class P04_Wishlist {
    WebDriver driver;

    By hotSellersSection = By.cssSelector(".block.widget.block-products-list.grid");
    By firstProductCard = By.cssSelector(".products-grid .product-item");
    By wishlistButton = By.cssSelector(".products-grid .product-item .action.towishlist");
    By wishlistPageTitle = By.cssSelector(".base"); // Usually contains "My Wish List"
    By wishlistItemName = By.cssSelector(".product-item-name a");
    By loginPageTitle = By.cssSelector(".page-title");

    public P04_Wishlist(WebDriver driver) {
        this.driver = driver;
    }

    public void scrollToHotSellers() {
        WebElement section = driver.findElement(hotSellersSection);
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", section);
    }

    public void hoverOnProductAndClickWishlist() {
        WebElement product = driver.findElement(firstProductCard);
        WebElement wishBtn = driver.findElement(wishlistButton);

        new Actions(driver).moveToElement(product).perform();
        wishBtn.click();
    }

    public boolean isLoginPageDisplayed() {
        return driver.findElement(loginPageTitle).getText().equalsIgnoreCase("Customer Login");
    }

    public boolean isWishlistPageDisplayed() {
        return driver.findElement(wishlistPageTitle).getText().equalsIgnoreCase("My Wish List");
    }

    public String getWishlistItemName() {
        return driver.findElement(wishlistItemName).getText();
    }
}
