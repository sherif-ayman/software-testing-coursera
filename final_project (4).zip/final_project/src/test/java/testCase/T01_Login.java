package testCase;

import Pages.P01_Login;
import Pages.P02_LoginAssertion;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class T01_Login {
    ChromeDriver driver;
    P01_Login loginPage;
    P02_LoginAssertion loginAssertion;
    @BeforeTest
    void setup()
    {
        driver = new ChromeDriver();
        driver.get("https://magento.softwaretestingboard.com/");
        loginPage = new P01_Login(driver);
        loginAssertion = new P02_LoginAssertion(driver);
    }
    @Test
    void login() throws InterruptedException {
        loginPage.clickSignIn();
        Thread.sleep(1000);

        loginPage.enterEmail("sherif1@gmail.com");
        loginPage.enterPassword("sherif1_");
        loginPage.clickLogin();
        Thread.sleep(2000);

        Assert.assertTrue(loginAssertion.isWelcomeDisplayed());
        Assert.assertTrue(loginAssertion.ishomepagedisplayed());
    }
    @AfterTest
    void finish()
    {
        driver.quit();

    }
}
