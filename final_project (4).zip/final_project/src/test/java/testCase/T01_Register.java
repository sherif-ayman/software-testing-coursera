package testCase;

import Pages.P01_Register;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.*;

public class T01_Register {

    WebDriver driver;
    P01_Register registerPage;

    @BeforeTest
    public void setup() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://magento.softwaretestingboard.com/");
        registerPage = new P01_Register(driver);
    }

    // TC1: Validate error message when Confirm Password is empty
    @Test
    public void testEmptyConfirmPassword() throws InterruptedException {
        registerPage.clickCreateAccount();
        Thread.sleep(1000);

        registerPage.enterFirstName("John");
        registerPage.enterLastName("Doe");
        registerPage.enterEmail("john.doe" + System.currentTimeMillis() + "@example.com");
        registerPage.enterPassword("StrongPassword123");
        registerPage.enterConfirmPassword("");  // Empty confirm password
        registerPage.clickRegister();
        Thread.sleep(2000);

        Assert.assertTrue(registerPage.isConfirmPasswordErrorDisplayed(), "Error message not displayed for empty Confirm Password.");
    }

    // TC2: Validate error message when Password and Confirm Password do not match
    @Test
    public void testPasswordMismatch() throws InterruptedException {
        registerPage.clickCreateAccount();
        Thread.sleep(1000);

        registerPage.enterFirstName("Jane");
        registerPage.enterLastName("Smith");
        registerPage.enterEmail("jane.smith" + System.currentTimeMillis() + "@example.com");
        registerPage.enterPassword("Password123");
        registerPage.enterConfirmPassword("DifferentPassword123");  // Mismatched confirm password
        registerPage.clickRegister();
        Thread.sleep(2000);

        Assert.assertTrue(registerPage.isPasswordMismatchErrorDisplayed(), "Error message not displayed for password mismatch.");
    }

    // TC3: Validate successful registration with valid data and navigation to "My Account"
    @Test
    public void testSuccessfulRegistration() throws InterruptedException {
        registerPage.clickCreateAccount();
        Thread.sleep(1000);

        String validEmail = "user" + System.currentTimeMillis() + "@example.com";

        registerPage.enterFirstName("Robert");
        registerPage.enterLastName("Brown");
        registerPage.enterEmail(validEmail);
        registerPage.enterPassword("ValidPassword123");
        registerPage.enterConfirmPassword("ValidPassword123");  // Matching passwords
        registerPage.clickRegister();
        Thread.sleep(3000);

        Assert.assertTrue(registerPage.isSuccessMessageDisplayed(), "Success message not displayed after registration.");
        System.out.println("Success Message: " + registerPage.getSuccessMessageText());
    }

    @AfterTest
    public void tearDown() {
        driver.quit();
    }
}
