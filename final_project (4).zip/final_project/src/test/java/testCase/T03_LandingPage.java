package testCase;

import Pages.P03_LandingPage;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.*;
import org.testng.Assert;
import org.testng.annotations.*;

import java.time.Duration;
import java.util.List;

public class T03_LandingPage {

    WebDriver driver;
    WebDriverWait wait;
    P03_LandingPage landingPage;

    @BeforeClass
    public void setUp() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        driver.get("https://magento.softwaretestingboard.com/");
        landingPage = new P03_LandingPage(driver);
    }

    @Test(priority = 1)
    public void TC1_validateHotSellersPrices() {
        try {
            List<WebElement> cards = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(
                    By.cssSelector(".block.widget.block-products-list.grid .product-item")
            ));

            Assert.assertFalse(cards.isEmpty(), "No Hot Seller cards found.");

            for (WebElement card : cards) {
                WebElement priceElement = card.findElement(By.cssSelector(".price"));
                Assert.assertTrue(priceElement.isDisplayed(), "Price is not displayed.");

                String priceText = priceElement.getText().replace("$", "").trim();
                try {
                    double price = Double.parseDouble(priceText);
                    Assert.assertTrue(price > 0, "Price should be greater than 0.");
                } catch (NumberFormatException e) {
                    Assert.fail("Price is not a valid number: " + priceText);
                }
            }
        } catch (TimeoutException e) {
            Assert.fail("Hot Sellers section not found or cards not loaded.");
        }
    }

    @Test(priority = 2)
    public void TC2_validateAddToCartButtons() {
        List<WebElement> cards = landingPage.hotSellerCards;
        Assert.assertFalse(cards.isEmpty(), "No Hot Seller cards available for Add to Cart check.");

        for (WebElement card : cards) {
            WebElement addToCartBtn = landingPage.getAddToCartButton(card);
            Assert.assertTrue(addToCartBtn.isDisplayed(), "Add to Cart button is not displayed.");
            Assert.assertTrue(addToCartBtn.isEnabled(), "Add to Cart button is not clickable.");
        }
    }

    @Test(priority = 3)
    public void TC3_guestUserCanAddProductToCart() {
        try {
            WebElement productCard = landingPage.getCardByName("Breathe-Easy Tank");
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", productCard);

            Actions actions = new Actions(driver);
            actions.moveToElement(productCard).perform();

            try {
                WebElement sizeOption = landingPage.getSizeOption(productCard, "M");
                wait.until(ExpectedConditions.elementToBeClickable(sizeOption)).click();
            } catch (NoSuchElementException | TimeoutException ignored) {}

            try {
                WebElement colorOption = landingPage.getColorOption(productCard);
                wait.until(ExpectedConditions.elementToBeClickable(colorOption)).click();
            } catch (NoSuchElementException | TimeoutException ignored) {}

            WebElement addToCart = landingPage.getAddToCartButton(productCard);
            wait.until(ExpectedConditions.elementToBeClickable(addToCart)).click();

            WebElement cartBadge = wait.until(ExpectedConditions.visibilityOf(landingPage.getCartBadge()));
            Assert.assertEquals(cartBadge.getText(), "1", "Cart should show 1 item.");
        } catch (TimeoutException e) {
            Assert.fail("Product 'Breathe-Easy Tank' not found or could not be added to cart.");
        }
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
