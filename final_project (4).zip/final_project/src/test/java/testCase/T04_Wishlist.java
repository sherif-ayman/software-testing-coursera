package testCase;

import Pages.P04_Wishlist;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.*;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.time.Duration;

public class T04_Wishlist {
    WebDriver driver;
    P04_Wishlist wishlist;

    @BeforeMethod
    public void setup() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.get("https://magento.softwaretestingboard.com/");
        wishlist = new P04_Wishlist(driver);
    }

    @Test(priority = 1)
    public void TC01_guestUserCannotAddToWishlist() {
        wishlist.scrollToHotSellers();
        wishlist.hoverOnProductAndClickWishlist();

        Assert.assertTrue(wishlist.isLoginPageDisplayed(), "Guest user was not redirected to login page.");
    }

    @Test(priority = 2)
    public void TC02_loggedInUserCanAddToWishlist() {
        navigateToLoginPage();
        performLogin("testuser@example.com", "Test@1234"); // Use valid test credentials

        wishlist.scrollToHotSellers();
        wishlist.hoverOnProductAndClickWishlist();

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.urlContains("wishlist"));

        Assert.assertTrue(wishlist.isWishlistPageDisplayed(), "User not redirected to My Wishlist.");
        Assert.assertFalse(wishlist.getWishlistItemName().isEmpty(), "Wishlist is empty.");
    }

    public void navigateToLoginPage() {
        driver.findElement(By.linkText("Sign In")).click();
    }

    public void performLogin(String email, String password) {
        driver.findElement(By.id("email")).sendKeys(email);
        driver.findElement(By.id("pass")).sendKeys(password);
        driver.findElement(By.id("send2")).click();
    }

    @AfterMethod
    public void tearDown() {
        driver.quit();
    }
}
